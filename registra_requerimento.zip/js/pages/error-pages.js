$(document).ready(function() {
 	
 	$("html").addClass("errorPage");
 	$(".errorContainer").toggle('fast');
 	
});