        $(function() {
            var data = {"0": { "areas": {"": {"text": {"content": ""}},"alto_do_parque": {"text": {"content": ""}},"americano": {"text": {"content": ""}},"bom_pastor": {"text": {"content": ""}},"campestre": {"text": {"content": ""}},"carneiros": {"text": {"content": ""}},"centenario": {"text": {"content": ""}},"centro": {"text": {"content": ""}},"conservas": {"text": {"content": ""}},"conventos": {"text": {"content": ""}},"floresta": {"text": {"content": ""}},"florestal": {"text": {"content": ""}},"hidraulica": {"text": {"content": ""}},"igrejinha": {"text": {"content": ""}},"imigrante": {"text": {"content": ""}},"jardim_do_cedro": {"text": {"content": ""}},"moinhos": {"text": {"content": ""}},"moinhos_dagua": {"text": {"content": ""}},"montanha": {"text": {"content": ""}},"morro_vinte_cinco": {"text": {"content": ""}},"nacoes": {"text": {"content": ""}},"olarias": {"text": {"content": ""}},"planalto": {"text": {"content": ""}},"santo_andre": {"text": {"content": ""}},"santo_antonio": {"text": {"content": ""}},"sao_bento": {"text": {"content": ""}},"sao_cristovao": {"text": {"content": ""}},"universitario": {"text": {"content": ""}},}},"1": { "areas": {"campestre": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Campestre</span><br />Requerimentos : 1"
                            }},"centro": {
                            "value": 3,
                            "attrs": { fill: "#6c98c9"},
                            "text": { "content":  "3" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 3"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"florestal": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Florestal</span><br />Requerimentos : 2"
                            }},"hidraulica": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 1"
                            }},"jardim_do_cedro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 1"
                            }},"olarias": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Olarias</span><br />Requerimentos : 1"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"2": { "areas": {"bom_pastor": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Bom Pastor</span><br />Requerimentos : 1"
                            }},"centro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 1"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"florestal": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Florestal</span><br />Requerimentos : 1"
                            }},"hidraulica": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 2"
                            }},"jardim_do_cedro": {
                            "value": 3,
                            "attrs": { fill: "#6c98c9"},
                            "text": { "content":  "3" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 3"
                            }},"moinhos_dagua": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 1"
                            }},"planalto": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 1"
                            }},"sao_cristovao": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 1"
                            }}}},"3": { "areas": {"centro": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 2"
                            }},"conventos": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 2"
                            }},"florestal": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Florestal</span><br />Requerimentos : 1"
                            }},"imigrante": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Imigrante</span><br />Requerimentos : 1"
                            }},"jardim_do_cedro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 1"
                            }},"sao_cristovao": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 2"
                            }},"universitario": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 2"
                            }}}},"4": { "areas": {"jardim_do_cedro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 1"
                            }},"planalto": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 1"
                            }}}},"5": { "areas": {"centro": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 2"
                            }},"sao_cristovao": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 1"
                            }}}},"6": { "areas": {"sao_cristovao": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 1"
                            }}}},"7": { "areas": {"moinhos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 1"
                            }},"planalto": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 1"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"8": { "areas": {"alto_do_parque": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Alto do Parque</span><br />Requerimentos : 2"
                            }},"bom_pastor": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Bom Pastor</span><br />Requerimentos : 2"
                            }},"campestre": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Campestre</span><br />Requerimentos : 1"
                            }},"centro": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 2"
                            }},"conservas": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conservas</span><br />Requerimentos : 1"
                            }},"conventos": {
                            "value": 3,
                            "attrs": { fill: "#6c98c9"},
                            "text": { "content":  "3" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 3"
                            }},"florestal": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Florestal</span><br />Requerimentos : 1"
                            }},"hidraulica": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 1"
                            }},"jardim_do_cedro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 1"
                            }},"moinhos": {
                            "value": 4,
                            "attrs": { fill: "#6a96c7"},
                            "text": { "content":  "4" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 4"
                            }},"moinhos_dagua": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 1"
                            }},"montanha": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Montanha</span><br />Requerimentos : 1"
                            }},"olarias": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Olarias</span><br />Requerimentos : 2"
                            }},"planalto": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 1"
                            }},"sao_cristovao": {
                            "value": 3,
                            "attrs": { fill: "#6c98c9"},
                            "text": { "content":  "3" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 3"
                            }},"universitario": {
                            "value": 4,
                            "attrs": { fill: "#6a96c7"},
                            "text": { "content":  "4" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 4"
                            }}}},"9": { "areas": {"centro": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 2"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"floresta": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Floresta</span><br />Requerimentos : 1"
                            }},"imigrante": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Imigrante</span><br />Requerimentos : 1"
                            }},"jardim_do_cedro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 1"
                            }},"moinhos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 1"
                            }},"moinhos_dagua": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 1"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"10": { "areas": {"conservas": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conservas</span><br />Requerimentos : 1"
                            }},"hidraulica": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 1"
                            }},"moinhos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 1"
                            }},"montanha": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Montanha</span><br />Requerimentos : 2"
                            }},"sao_cristovao": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 1"
                            }}}},"11": { "areas": {"campestre": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Campestre</span><br />Requerimentos : 1"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"jardim_do_cedro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 1"
                            }},"moinhos_dagua": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 1"
                            }},"planalto": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 2"
                            }}}},"12": { "areas": {"centro": {
                            "value": 4,
                            "attrs": { fill: "#6a96c7"},
                            "text": { "content":  "4" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 4"
                            }},"hidraulica": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 2"
                            }},"moinhos": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 2"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"13": { "areas": {"sao_cristovao": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 2"
                            }}}},"14": { "areas": {"centenario": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centenário</span><br />Requerimentos : 2"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"floresta": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Floresta</span><br />Requerimentos : 1"
                            }},"igrejinha": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Igrejinha</span><br />Requerimentos : 1"
                            }},"imigrante": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Imigrante</span><br />Requerimentos : 1"
                            }},"moinhos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 1"
                            }},"planalto": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 2"
                            }}}},"15": { "areas": {"alto_do_parque": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Alto do Parque</span><br />Requerimentos : 1"
                            }},"bom_pastor": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Bom Pastor</span><br />Requerimentos : 1"
                            }},"carneiros": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Carneiros</span><br />Requerimentos : 1"
                            }},"centro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 1"
                            }},"igrejinha": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Igrejinha</span><br />Requerimentos : 1"
                            }},"moinhos_dagua": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 1"
                            }},"montanha": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Montanha</span><br />Requerimentos : 1"
                            }},"olarias": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Olarias</span><br />Requerimentos : 1"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"16": { "areas": {"campestre": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Campestre</span><br />Requerimentos : 1"
                            }},"carneiros": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Carneiros</span><br />Requerimentos : 1"
                            }},"centenario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centenário</span><br />Requerimentos : 1"
                            }},"centro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 1"
                            }},"imigrante": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Imigrante</span><br />Requerimentos : 1"
                            }},"sao_cristovao": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 1"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"17": { "areas": {"centro": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 1"
                            }},"nacoes": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Nações</span><br />Requerimentos : 1"
                            }}}},"18": { "areas": {"hidraulica": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 1"
                            }},"moinhos_dagua": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 2"
                            }},"universitario": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Universitário</span><br />Requerimentos : 1"
                            }}}},"19": { "areas": {"centro": {
                            "value": 3,
                            "attrs": { fill: "#6c98c9"},
                            "text": { "content":  "3" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 3"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"olarias": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Olarias</span><br />Requerimentos : 1"
                            }}}},"20": { "areas": {"centro": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 2"
                            }}}},"21": { "areas": {"americano": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Americano</span><br />Requerimentos : 1"
                            }},"centro": {
                            "value": 16,
                            "attrs": { fill: "#527db2"},
                            "text": { "content":  "16" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Centro</span><br />Requerimentos : 16"
                            }},"conventos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Conventos</span><br />Requerimentos : 1"
                            }},"hidraulica": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Hidráulica</span><br />Requerimentos : 2"
                            }},"igrejinha": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Igrejinha</span><br />Requerimentos : 1"
                            }},"jardim_do_cedro": {
                            "value": 3,
                            "attrs": { fill: "#6c98c9"},
                            "text": { "content":  "3" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Jardim do Cedro</span><br />Requerimentos : 3"
                            }},"moinhos": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos</span><br />Requerimentos : 1"
                            }},"moinhos_dagua": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Moinhos D' Água</span><br />Requerimentos : 1"
                            }},"montanha": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Montanha</span><br />Requerimentos : 1"
                            }},"planalto": {
                            "value": 1,
                            "attrs": { fill: "#709ccd"},
                            "text": { "content":  "1" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">Planalto</span><br />Requerimentos : 1"
                            }},"sao_cristovao": {
                            "value": 2,
                            "attrs": { fill: "#6e9acb"},
                            "text": { "content":  "2" , attrs: {fill:"#222"} },
                            "tooltip": {
                                    "content": "<span style=\"font-weight:bold;\">São Cristóvão</span><br />Requerimentos : 2"
                            }}}},};
                        $("#cat_requerimento").change(function() {
            value = $("#cat_requerimento").val();

              $(".maparea1").trigger('update', [data[0], {}, {}, {animDuration: 500}]);

              $(".maparea1").trigger('update', [data[value], {}, {}, {animDuration: 1000,resetPlots:true, resetAreas:true  }]);
          });

            // Mapael initialisation
            $(".maparea1").mapael({
                map: {
                    name: "lajeado",
                    width: 700,
                    defaultArea: {
                        attrs: {
                            fill: "#cadbed",
                            stroke: "#82bfec",
                            "stroke-width": 0.3
                        }
                    },
                    defaultPlot: {
                        text: {
                            attrs: {
                                fill: "#613b1e",
                                "font-weight": "bold"
                            },
                            attrsHover: {
                                fill: "#f99200",
                                "font-weight": "bold"
                            }
                        }
                    }
                },
                areas: data[0]['areas']

            });
        });